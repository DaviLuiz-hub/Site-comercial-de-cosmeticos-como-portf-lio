const slides = [...document.querySelectorAll('.slide')];
const dotsWrap = document.querySelector('.dots');
let slideIndex = 0;
let timer;

slides.forEach((_, i) => {
  const b = document.createElement('button');
  b.setAttribute('aria-label', `Ir para slide ${i + 1}`);
  if (i === 0) b.classList.add('active');
  b.addEventListener('click', () => goToSlide(i, true));
  dotsWrap.appendChild(b);
});
const dots = [...dotsWrap.children];

function goToSlide(index, reset=false) {
  slides[slideIndex].classList.remove('active');
  dots[slideIndex].classList.remove('active');
  slideIndex = (index + slides.length) % slides.length;
  slides[slideIndex].classList.add('active');
  dots[slideIndex].classList.add('active');
  if (reset) startAuto();
}
function startAuto(){
  clearInterval(timer);
  timer = setInterval(() => goToSlide(slideIndex + 1), 5500);
}
document.querySelector('.slider-arrow.prev').addEventListener('click', () => goToSlide(slideIndex - 1, true));
document.querySelector('.slider-arrow.next').addEventListener('click', () => goToSlide(slideIndex + 1, true));
startAuto();

const track = document.querySelector('.product-track');
const scrollProducts = (dir) => track.scrollBy({left: dir * track.clientWidth * .78, behavior:'smooth'});
document.querySelector('.product-arrow.left').addEventListener('click', () => scrollProducts(-1));
document.querySelector('.product-arrow.right').addEventListener('click', () => scrollProducts(1));

let cart = 0;
const cartCount = document.querySelector('.cart-count');
document.querySelectorAll('.add-cart').forEach(btn => btn.addEventListener('click', () => {
  cart += 1;
  cartCount.textContent = cart;
  btn.animate([{transform:'scale(1)'},{transform:'scale(1.3)'},{transform:'scale(1)'}], {duration:260});
}));

const searchPanel = document.querySelector('.search-panel');
document.querySelector('[data-search]').addEventListener('click', () => {
  searchPanel.classList.add('open');
  searchPanel.setAttribute('aria-hidden','false');
  setTimeout(() => searchPanel.querySelector('input').focus(), 80);
});
document.querySelector('.search-close').addEventListener('click', closeSearch);
searchPanel.addEventListener('click', e => { if(e.target === searchPanel) closeSearch(); });
document.addEventListener('keydown', e => { if(e.key === 'Escape') closeSearch(); });
function closeSearch(){
  searchPanel.classList.remove('open');
  searchPanel.setAttribute('aria-hidden','true');
}
