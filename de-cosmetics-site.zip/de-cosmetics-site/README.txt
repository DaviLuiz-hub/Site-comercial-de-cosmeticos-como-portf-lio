D&E Cosmetics - site estático inspirado no layout de referência.

Arquivos:
- index.html
- style.css
- script.js

Como abrir:
1. Mantenha os 3 arquivos na mesma pasta.
2. Abra index.html no navegador.

Observação:
As imagens de produto/categoria usam URLs externas do Unsplash. Para um site de produção, substitua pelos arquivos reais dos seus produtos.
